//
//  ViewController.swift
//  correcaoPickerView
//
//  Created by Jessica Santana on 09/05/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var cronometroPickerView: UIPickerView!
    @IBOutlet weak var informacaoCronometroLabel: UILabel!
    
    var horas: [String] = []
    var minutos: [String] = []
    var segundos: [String] = []
    
    var valorHora: String = ""
    var valorMinuto: String = ""
    var valorSegundo: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // inicializa o array de horas
        for index in 0..<24 {
            let stringHora = String(index)
            horas.append(stringHora)
        }
        
        // inicializa o array de minutos
        for index in 0..<60 {
            let stringMinuto = String(index)
            minutos.append(stringMinuto)
        }
        
        // inicializa o array de segundos
        for index in 0..<60 {
            let stringSegundo = String(index)
            segundos.append(stringSegundo)
        }
        
        cronometroPickerView.delegate = self
        cronometroPickerView.dataSource = self
        
        valorHora = horas[0]
        valorMinuto = minutos[0]
        valorSegundo = segundos[0]
    }
    
    
    @IBAction func cancelarAction(_ sender: Any) {
        // a label debaixo deve ser zerada e voltar para o texto inicial
        informacaoCronometroLabel.text = "0 Horas, 0 min e 0 seg"
    }
    
    @IBAction func iniciarAction(_ sender: Any) {
        // a label debaixo deve estar escrita com a hora selecionada no pickerView
        
        informacaoCronometroLabel.text = "\(valorHora) Horas, \(valorMinuto) min e \(valorSegundo) seg"
    }    
}

extension ViewController: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            valorHora = horas[row]
        }
        
        if component == 1 {
            valorMinuto = minutos[row]
        }
        
        if component == 2 {
            valorSegundo = segundos[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 { // horas
            return "\(horas[row]) horas"
        }
        
        if component == 1 { // minutos
            return "\(minutos[row]) min"
        }
        
        if component == 2 { // segundos
            return "\(segundos[row]) seg"
        }
        
        return nil
    }
    
}

extension ViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 { return horas.count }
        if component == 1 { return minutos.count }
        if component == 2 { return segundos.count }
        
        return 0
    }
}

